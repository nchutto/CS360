@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.nicolehutto_projecttwo

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.compose.*


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AppNavigation() } }
    }
}

/** Navigation routes */
object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val GRID = "grid"
    const val SMS = "sms"
}

/** Data model for grid */
data class WeightEntry(
    val id: Long,
    val weight: Double,
    val notes: String,
    val timestamp: Long
)



/** SQLite helper (Users + WeightEntries) */
class AppDb(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // Users table
        db.execSQL(
            """
            CREATE TABLE $TBL_USERS (
              $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
              $COL_USERNAME TEXT UNIQUE NOT NULL,
              $COL_PASSWORD TEXT NOT NULL
            )
            """.trimIndent()
        )

        // Weight entries table
        db.execSQL(
            """
            CREATE TABLE $TBL_WEIGHTS (
                $COL_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WEIGHT_VALUE REAL NOT NULL,
                $COL_WEIGHT_NOTES TEXT,
                $COL_WEIGHT_TS INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TBL_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TBL_WEIGHTS")
        onCreate(db)
    }

    fun userCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM $TBL_USERS", null).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun createUser(username: String, password: String): Boolean {
        val cv = ContentValues().apply {
            put(COL_USERNAME, username.trim())
            put(COL_PASSWORD, password)
        }
        return try {
            writableDatabase.insertOrThrow(TBL_USERS, null, cv) > 0
        } catch (_: Exception) {
            false
        }
    }

    fun validateLogin(username: String, password: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT $COL_USER_ID FROM $TBL_USERS WHERE $COL_USERNAME=? AND $COL_PASSWORD=?",
            arrayOf(username.trim(), password)
        ).use { c ->
            return c.moveToFirst()
        }
    }

    fun addWeight(weight: Double, notes: String): Long {
        val cv = ContentValues().apply {
            put(COL_WEIGHT_VALUE, weight)
            put(COL_WEIGHT_NOTES, notes)
            put(COL_WEIGHT_TS, System.currentTimeMillis())
        }
        return writableDatabase.insert(TBL_WEIGHTS, null, cv)
    }

    fun updateWeight(id: Long, weight: Double, notes: String): Boolean {
        val cv = ContentValues().apply {
            put(COL_WEIGHT_VALUE, weight)
            put(COL_WEIGHT_NOTES, notes)
        }
        return writableDatabase.update(
            TBL_WEIGHTS,
            cv,
            "$COL_WEIGHT_ID=?",
            arrayOf(id.toString())
        ) > 0
    }

    fun deleteWeight(id: Long): Boolean {
        return writableDatabase.delete(
            TBL_WEIGHTS,
            "$COL_WEIGHT_ID=?",
            arrayOf(id.toString())
        ) > 0
    }

    fun getAllWeights(): List<WeightEntry> {
        val result = mutableListOf<WeightEntry>()
        readableDatabase.rawQuery(
            "SELECT $COL_WEIGHT_ID,$COL_WEIGHT_VALUE,$COL_WEIGHT_NOTES,$COL_WEIGHT_TS FROM $TBL_WEIGHTS ORDER BY $COL_WEIGHT_TS DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result.add(
                    WeightEntry(
                        id = c.getLong(0),
                        weight = c.getDouble(1),
                        notes = c.getString(2) ?: "",
                        timestamp = c.getLong(3)
                    )
                )
            }
        }
        return result
    }


    companion object {
        private const val DB_NAME = "weight_tracker.db"
        private const val DB_VERSION = 1

        private const val TBL_USERS = "users"
        private const val TBL_WEIGHTS = "weights"

        private const val COL_USER_ID = "id"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"

        private const val COL_WEIGHT_ID = "id"
        private const val COL_WEIGHT_VALUE = "weight"
        private const val COL_WEIGHT_NOTES = "notes"
        private const val COL_WEIGHT_TS = "timestamp"

    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val db = remember { AppDb(context) }

    // shared app state (simple, single-user)
    var smsAllowed by remember { mutableStateOf(false) }
    var smsPhone by remember { mutableStateOf("") }

    NavHost(navController = navController, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(
                navController = navController,
                db = db
            )
        }
        composable(Routes.REGISTER) {
            RegisterScreen(
                navController = navController,
                db = db
            )
        }
        composable(Routes.GRID) {
            WeightGridScreen(
                navController = navController,
                db = db,
                smsAllowed = smsAllowed,
                smsPhone = smsPhone
            )
        }
        composable(Routes.SMS) {
            SmsPermissionScreen(
                navController = navController,
                onPermissionResult = { allowed -> smsAllowed = allowed },
                onPhoneSaved = { smsPhone = it }
            )
        }
    }
}

/* ------------------------------ LOGIN ------------------------------ */

@Composable
fun LoginScreen(navController: NavController, db: AppDb) {
    val context = LocalContext.current

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val hasUsers = remember { db.userCount() > 0 }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Weight Tracker Login") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Please sign in", fontWeight = FontWeight.SemiBold)

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val ok = db.validateLogin(username, password)
                    if (ok) {
                        navController.navigate(Routes.GRID) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    } else {
                        Toast.makeText(
                            context,
                            if (!hasUsers) "No users yet. Please create an account."
                            else "Invalid username/password.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Login")
            }

            OutlinedButton(
                onClick = { navController.navigate(Routes.REGISTER) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create New Account")
            }

            Text(
                text = "Create an account to save your progress.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/* ------------------------------ REGISTER ------------------------------ */

@Composable
fun RegisterScreen(navController: NavController, db: AppDb) {
    val context = LocalContext.current

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Create Account") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("New Username") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("New Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it },
                label = { Text("Confirm Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val u = username.trim()
                    if (u.isEmpty() || password.isEmpty()) {
                        Toast.makeText(context, "Username and password required.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (password != confirm) {
                        Toast.makeText(context, "Passwords do not match.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    val created = db.createUser(u, password)
                    if (created) {
                        Toast.makeText(context, "Account created. Please log in.", Toast.LENGTH_SHORT).show()
                        navController.popBackStack()
                    } else {
                        Toast.makeText(context, "Username already exists. Try another.", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Account")
            }

            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back to Login")
            }
        }
    }
}

/* ------------------------------ GRID + CRUD ------------------------------ */

@Composable
fun WeightGridScreen(
    navController: NavController,
    db: AppDb,
    smsAllowed: Boolean,
    smsPhone: String
) {
    fun formatDate(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("MM/dd/yyyy", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timestamp))
    }

    val context = LocalContext.current

    // Example notification trigger
    val goalWeight = 150.0

    var weightText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var editDialogOpen by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<Long?>(null) }
    var editWeightText by remember { mutableStateOf("") }
    var editNotes by remember { mutableStateOf("") }

    var entries by remember { mutableStateOf(db.getAllWeights()) }

    fun refresh() { entries = db.getAllWeights() }

    fun maybeSendGoalSms(currentWeight: Double) {
        if (!smsAllowed) return
        if (smsPhone.trim().isEmpty()) return
        if (currentWeight <= goalWeight) {
            try {
                val sms = context.getSystemService(SmsManager::class.java)
                sms.sendTextMessage(
                    smsPhone.trim(),
                    null,
                    "Weight Tracker: Congrats! You reached your goal weight ($goalWeight).",
                    null,
                    null
                )
                Toast.makeText(context, "Goal SMS sent.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "SMS failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Weight Entries") },
                actions = {
                    TextButton(onClick = { navController.navigate(Routes.SMS) }) {
                        Text("SMS")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Add area (Create)
            Text("Add Entry", fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = weightText,
                onValueChange = { weightText = it },
                label = { Text("Weight (e.g., 175.5)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val w = weightText.toDoubleOrNull()
                    if (w == null) {
                        Toast.makeText(context, "Enter a valid number for weight.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    db.addWeight(w, notes)
                    weightText = ""
                    notes = ""
                    refresh()
                    maybeSendGoalSms(w)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Entry")
            }

            HorizontalDivider()

            // Display Area (Read) as a grid
            Text("Database Items (Grid)", fontWeight = FontWeight.Bold)

            if (entries.isEmpty()) {
                Text("No entries yet. Add one above.")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Weight: ${entry.weight}", fontWeight = FontWeight.SemiBold)
                                Text("Date: ${formatDate(entry.timestamp)}")
                                if (entry.notes.isNotBlank()) Text(entry.notes)

                                Spacer(Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            editId = entry.id
                                            editWeightText = entry.weight.toString()
                                            editNotes = entry.notes
                                            editDialogOpen = true
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Text("Edit", maxLines = 1)
                                    }

                                    Button(
                                        onClick = {
                                            db.deleteWeight(entry.id)
                                            refresh()
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Text("Delete", maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Update dialog (Update)
    if (editDialogOpen) {
        AlertDialog(
            onDismissRequest = { editDialogOpen = false },
            title = { Text("Update Entry") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editWeightText,
                        onValueChange = { editWeightText = it },
                        label = { Text("Weight") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editNotes,
                        onValueChange = { editNotes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val id = editId
                    val w = editWeightText.toDoubleOrNull()
                    if (id == null || w == null) {
                        Toast.makeText(context, "Invalid update values.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    db.updateWeight(id, w, editNotes)
                    editDialogOpen = false
                    refresh()
                    maybeSendGoalSms(w)
                }) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { editDialogOpen = false }) { Text("Cancel") }
            }
        )
    }
}

/* ------------------------------ SMS PERMISSION SCREEN ------------------------------ */

@Composable
fun SmsPermissionScreen(
    navController: NavController,
    onPermissionResult: (Boolean) -> Unit,
    onPhoneSaved: (String) -> Unit
) {
    val context = LocalContext.current
    var phone by remember { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onPermissionResult(granted)
        Toast.makeText(
            context,
            if (granted) "SMS permission granted." else "SMS permission denied. App still works.",
            Toast.LENGTH_SHORT
        ).show()
    }

    val currentGranted = remember {
        ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("SMS Notifications") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "This app can send an SMS when you reach your goal weight.\n" +
                        "If you deny permission, the rest of the app still works.",
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone number to text") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    onPhoneSaved(phone)
                    Toast.makeText(context, "Phone saved.", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save Phone") }

            Button(
                onClick = {
                    val already = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.SEND_SMS
                    ) == PackageManager.PERMISSION_GRANTED

                    if (already) {
                        onPermissionResult(true)
                        Toast.makeText(context, "Already granted.", Toast.LENGTH_SHORT).show()
                    } else {
                        launcher.launch(Manifest.permission.SEND_SMS)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (currentGranted) "Permission Already Granted" else "Request SMS Permission")
            }

            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Back") }
        }
    }
}
